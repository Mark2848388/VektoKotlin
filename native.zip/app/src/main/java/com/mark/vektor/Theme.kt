package com.mark.vektor

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

data class VColors(
    val bg: Color,
    val card: Color,
    val card2: Color,
    val line: Color,
    val text: Color,
    val muted: Color,
    val accent: Color,
    val onAccent: Color,
    val bubble: Color,
    val dark: Boolean
)

val Palettes: Map<String, VColors> = linkedMapOf(
    "warm" to VColors(
        Color(0xFF262624), Color(0xFF30302E), Color(0xFF3A3A37), Color(0xFF45443F),
        Color(0xFFF2EFE8), Color(0xFFA09D94), Color(0xFFD97757), Color(0xFFFFFFFF), Color(0xFF3A3A37), true
    ),
    "black" to VColors(
        Color(0xFF0D0D0E), Color(0xFF171718), Color(0xFF202022), Color(0xFF2B2B2E),
        Color(0xFFECECED), Color(0xFF8D8D93), Color(0xFFF2F2F3), Color(0xFF111111), Color(0xFF2A2A2D), true
    ),
    "gray" to VColors(
        Color(0xFF2A2A2D), Color(0xFF343437), Color(0xFF3E3E42), Color(0xFF4A4A4F),
        Color(0xFFEFEFF1), Color(0xFFA5A5AB), Color(0xFFFAFAFA), Color(0xFF111111), Color(0xFF4A4A4F), true
    ),
    "paper" to VColors(
        Color(0xFFFAF9F5), Color(0xFFFFFFFF), Color(0xFFF0EEE6), Color(0xFFE3DFD3),
        Color(0xFF1F1E1D), Color(0xFF7A776D), Color(0xFFC6613F), Color(0xFFFFFFFF), Color(0xFFECE9DE), false
    )
)

@Composable
fun VektorTheme(v: VColors, content: @Composable () -> Unit) {
    val scheme = if (v.dark) {
        darkColorScheme(
            primary = v.accent, onPrimary = v.onAccent, background = v.bg, onBackground = v.text,
            surface = v.card, onSurface = v.text, surfaceVariant = v.card2, onSurfaceVariant = v.muted,
            outline = v.line, secondary = v.accent, onSecondary = v.onAccent
        )
    } else {
        lightColorScheme(
            primary = v.accent, onPrimary = v.onAccent, background = v.bg, onBackground = v.text,
            surface = v.card, onSurface = v.text, surfaceVariant = v.card2, onSurfaceVariant = v.muted,
            outline = v.line, secondary = v.accent, onSecondary = v.onAccent
        )
    }
    MaterialTheme(colorScheme = scheme, content = content)
}
