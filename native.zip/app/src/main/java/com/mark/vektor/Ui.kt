package com.mark.vektor

import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.scrollBy
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ModalDrawerSheet
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberDrawerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch
import java.util.Calendar

@Composable
fun VektorApp(vm: ChatVM) {
    val v = Palettes[vm.theme] ?: Palettes.getValue("warm")
    VektorTheme(v) { Root(vm, v) }
}

@Composable
fun Root(vm: ChatVM, v: VColors) {
    val ctx = LocalContext.current
    val drawer = rememberDrawerState(DrawerValue.Closed)
    val scope = rememberCoroutineScope()
    var showProviders by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        vm.events.collect { Toast.makeText(ctx, it, Toast.LENGTH_SHORT).show() }
    }

    ModalNavigationDrawer(
        drawerState = drawer,
        drawerContent = {
            DrawerContent(vm, v, onClose = { scope.launch { drawer.close() } }, onProviders = { showProviders = true })
        }
    ) {
        Column(Modifier.fillMaxSize().background(v.bg).systemBarsPadding().imePadding()) {
            TopBar(vm, v, onMenu = { vm.saveCurrent(); scope.launch { drawer.open() } })
            Box(Modifier.weight(1f)) { ChatList(vm, v) }
            Composer(vm, v, onProviders = { showProviders = true })
        }
    }
    if (showProviders) ProvidersDialog(vm, v) { showProviders = false }
}

@Composable
fun TopBar(vm: ChatVM, v: VColors, onMenu: () -> Unit) {
    Row(Modifier.fillMaxWidth().padding(horizontal = 6.dp, vertical = 2.dp), verticalAlignment = Alignment.CenterVertically) {
        IconButton(onClick = onMenu) { Icon(Icons.Default.Menu, contentDescription = "Меню", tint = v.text) }
        Box(Modifier.weight(1f), contentAlignment = Alignment.Center) {
            if (vm.mode == "code") {
                Text(
                    "VKTR CODE", color = v.onAccent, fontSize = 11.sp, fontWeight = FontWeight.Bold,
                    modifier = Modifier.background(v.accent, RoundedCornerShape(20.dp)).padding(horizontal = 12.dp, vertical = 4.dp)
                )
            }
        }
        IconButton(onClick = { vm.newChat() }) { Icon(Icons.Default.Edit, contentDescription = "Новый чат", tint = v.text) }
    }
}

@Composable
fun ChatList(vm: ChatVM, v: VColors) {
    val state = rememberLazyListState()
    LaunchedEffect(vm.messages.size, vm.live?.length, vm.busy) {
        val n = state.layoutInfo.totalItemsCount
        if (n > 0) {
            state.scrollToItem(n - 1)
            state.scrollBy(1_000_000f)
        }
    }
    LazyColumn(
        state = state,
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        val live = vm.live
        if (vm.messages.isEmpty() && live == null) item { Welcome(vm, v) }
        itemsIndexed(vm.messages) { _, m -> MessageView(m, v, vm) }
        if (live != null) {
            item { MdView(live, v, true) { } }
        } else if (vm.busy) {
            item { Text(if (vm.status.isNotEmpty()) vm.status else "Думаю…", color = v.muted, fontSize = 14.sp) }
        }
    }
}

private fun greeting(name: String): String {
    val h = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
    val g = when {
        h < 5 -> "Доброй ночи"
        h < 12 -> "Доброе утро"
        h < 18 -> "Добрый день"
        else -> "Добрый вечер"
    }
    return if (name.isNotBlank()) "$g, $name." else "$g."
}

@Composable
fun Welcome(vm: ChatVM, v: VColors) {
    Column(Modifier.fillMaxWidth().padding(top = 48.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        if (vm.mode == "code") {
            Text("VKTR Code", color = v.text, fontSize = 30.sp, fontFamily = FontFamily.Serif)
            Text(
                "Отдельные чаты только для программирования. Опишите задачу: я напишу файлы, проверю их и упакую в ZIP.",
                color = v.muted, fontSize = 14.sp, modifier = Modifier.padding(vertical = 10.dp)
            )
            val ideas = listOf(
                "Сделай калькулятор на HTML и запакуй в zip",
                "Напиши Telegram-бота на Python",
                "Сделай сайт-визитку и запакуй в zip",
                "Напиши скрипт, который переименует файлы в папке"
            )
            for (t in ideas) {
                Box(
                    Modifier.padding(vertical = 4.dp).fillMaxWidth()
                        .border(1.dp, v.line, RoundedCornerShape(14.dp))
                        .background(v.card, RoundedCornerShape(14.dp))
                        .clickable { vm.input = t }
                        .padding(14.dp)
                ) { Text(t, color = v.text, fontSize = 14.sp) }
            }
        } else {
            Text(greeting(vm.userName), color = v.text, fontSize = 32.sp, fontFamily = FontFamily.Serif)
            if (vm.providers.isEmpty()) {
                Text(
                    "Подключите нейросеть: нажмите на кнопку внизу рядом с «+» и добавьте ключ.",
                    color = v.muted, fontSize = 14.sp, modifier = Modifier.padding(top = 14.dp)
                )
            }
        }
    }
}

@Composable
fun ActionRow(v: VColors, items: List<Pair<String, () -> Unit>>) {
    Row {
        for ((t, f) in items) {
            Text(
                t, color = v.muted, fontSize = 12.sp,
                modifier = Modifier.clickable(onClick = f).padding(horizontal = 8.dp, vertical = 8.dp)
            )
        }
    }
}

@Composable
fun MessageView(m: Msg, v: VColors, vm: ChatVM) {
    val ctx = LocalContext.current
    val clip = LocalClipboardManager.current
    val copy: (String) -> Unit = { t ->
        clip.setText(AnnotatedString(t))
        Toast.makeText(ctx, "Скопировано", Toast.LENGTH_SHORT).show()
    }
    when (m.role) {
        "user" -> Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.End) {
            Box(Modifier.widthIn(max = 320.dp).background(v.bubble, RoundedCornerShape(20.dp)).padding(horizontal = 14.dp, vertical = 10.dp)) {
                Column {
                    Text(m.text, color = v.text, fontSize = 16.sp)
                    for (a in m.atts) Text("📎 $a", color = v.muted, fontSize = 12.sp)
                }
            }
            ActionRow(v, listOf("Копировать" to { copy(m.text) }))
        }
        "assistant" -> Column(Modifier.fillMaxWidth()) {
            MdView(m.text, v, true, copy)
            ActionRow(
                v,
                listOf(
                    "Копировать" to { copy(m.text) },
                    "Поделиться" to { Files.shareText(ctx, m.text) },
                    "Сохранить" to {
                        try {
                            val where = Files.saveDownload(ctx, "vektor-" + System.currentTimeMillis() + ".md", "text/markdown", m.text.toByteArray())
                            Toast.makeText(ctx, "Сохранено: $where", Toast.LENGTH_LONG).show()
                        } catch (e: Exception) {
                            Toast.makeText(ctx, "Не удалось сохранить", Toast.LENGTH_SHORT).show()
                        }
                    }
                )
            )
        }
        else -> Text(m.text, color = v.muted, fontSize = 13.sp)
    }
}

@Composable
fun AttTray(vm: ChatVM, v: VColors) {
    LazyRow(Modifier.fillMaxWidth().padding(bottom = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        items(vm.atts.size) { i ->
            val a = vm.atts.getOrNull(i)
            if (a != null) {
                Box {
                    val th = a.thumb
                    if (th != null) {
                        Image(
                            bitmap = th.asImageBitmap(), contentDescription = a.name, contentScale = ContentScale.Crop,
                            modifier = Modifier.size(64.dp).clip(RoundedCornerShape(14.dp))
                        )
                    } else {
                        Row(
                            Modifier.height(64.dp).widthIn(max = 220.dp)
                                .background(v.card, RoundedCornerShape(14.dp))
                                .border(1.dp, v.line, RoundedCornerShape(14.dp))
                                .padding(start = 12.dp, end = 30.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(if (a.kind == "zip") "🗜" else if (a.kind == "doc") "📄" else if (a.kind == "text") "📝" else "📦", fontSize = 22.sp)
                            Column(Modifier.padding(start = 8.dp)) {
                                Text(a.name, color = v.text, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                Text(
                                    Files.fmtSize(a.size) + if (a.files.isNotEmpty()) " · " + a.files.size + " текст. файлов" else "",
                                    color = v.muted, fontSize = 11.sp
                                )
                            }
                        }
                    }
                    Text(
                        "×", color = v.text, fontSize = 16.sp,
                        modifier = Modifier.align(Alignment.TopEnd).padding(3.dp).size(22.dp)
                            .background(v.card2, CircleShape).clickable { vm.removeAtt(i) }
                            .padding(top = 0.dp),
                    )
                }
            }
        }
    }
}

@Composable
fun Composer(vm: ChatVM, v: VColors, onProviders: () -> Unit) {
    val ctx = LocalContext.current
    var menu by remember { mutableStateOf(false) }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetMultipleContents()) { uris: List<Uri> ->
        if (uris.isNotEmpty()) vm.addUris(ctx, uris)
    }
    var camUri by remember { mutableStateOf<Uri?>(null) }
    val cam = rememberLauncherForActivityResult(ActivityResultContracts.TakePicture()) { ok: Boolean ->
        val u = camUri
        if (ok && u != null) vm.addUris(ctx, listOf(u))
    }
    val canSend = vm.input.isNotBlank() || vm.atts.isNotEmpty()

    Column(Modifier.fillMaxWidth().padding(horizontal = 10.dp).padding(bottom = 4.dp)) {
        if (vm.atts.isNotEmpty()) AttTray(vm, v)
        Column(
            Modifier.fillMaxWidth()
                .background(v.card, RoundedCornerShape(26.dp))
                .border(1.dp, v.line, RoundedCornerShape(26.dp))
                .padding(start = 16.dp, end = 10.dp, top = 12.dp, bottom = 10.dp)
        ) {
            BasicTextField(
                value = vm.input,
                onValueChange = { vm.input = it },
                modifier = Modifier.fillMaxWidth().heightIn(min = 28.dp, max = 160.dp),
                textStyle = TextStyle(color = v.text, fontSize = 16.sp),
                cursorBrush = SolidColor(v.accent),
                decorationBox = { inner ->
                    Box {
                        if (vm.input.isEmpty()) {
                            Text(
                                if (vm.mode == "code") "Опишите, что написать или исправить…" else "Сообщение для Вектора…",
                                color = v.muted, fontSize = 16.sp
                            )
                        }
                        inner()
                    }
                }
            )
            Spacer(Modifier.height(8.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box {
                    Box(
                        Modifier.size(40.dp).clip(CircleShape).background(v.card2).clickable { menu = true },
                        contentAlignment = Alignment.Center
                    ) { Text("+", color = v.text, fontSize = 24.sp) }
                    DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                        DropdownMenuItem(text = { Text("Камера") }, onClick = {
                            menu = false
                            val u = Files.newCameraUri(ctx)
                            camUri = u
                            cam.launch(u)
                        })
                        DropdownMenuItem(text = { Text("Фото из галереи (можно несколько)") }, onClick = {
                            menu = false
                            picker.launch("image/*")
                        })
                        DropdownMenuItem(text = { Text("Файлы и ZIP (любые)") }, onClick = {
                            menu = false
                            picker.launch("*/*")
                        })
                    }
                }
                Spacer(Modifier.size(8.dp))
                Box(
                    Modifier.clip(RoundedCornerShape(20.dp)).background(v.card2).clickable { onProviders() }
                        .padding(horizontal = 14.dp, vertical = 10.dp)
                ) { Text(vm.activeName(), color = v.text, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.widthIn(max = 150.dp)) }
                Spacer(Modifier.weight(1f))
                Box(
                    Modifier.size(42.dp).clip(CircleShape)
                        .background(if (canSend || vm.busy) v.accent else v.card2)
                        .clickable { if (vm.busy) vm.stop() else vm.send() },
                    contentAlignment = Alignment.Center
                ) {
                    Text(if (vm.busy) "■" else "➤", color = if (canSend || vm.busy) v.onAccent else v.muted, fontSize = 18.sp)
                }
            }
        }
        Text(
            "Вектор " + Config.VERSION + " · ИИ может ошибаться. Проверяйте важное",
            color = v.muted, fontSize = 11.sp, modifier = Modifier.fillMaxWidth().padding(top = 6.dp),
            textAlign = androidx.compose.ui.text.style.TextAlign.Center
        )
    }
}

@Composable
fun DrawerContent(vm: ChatVM, v: VColors, onClose: () -> Unit, onProviders: () -> Unit) {
    val ctx = LocalContext.current
    var filter by remember { mutableStateOf("all") }
    var query by remember { mutableStateOf("") }
    val list = vm.sessions.filter { (filter == "all" || it.mode == filter) && (query.isBlank() || it.title.contains(query, ignoreCase = true)) }

    ModalDrawerSheet(drawerContainerColor = v.bg, drawerContentColor = v.text) {
        Column(Modifier.fillMaxHeight().padding(12.dp)) {
            Text("ВЕКТОР", color = v.text, fontWeight = FontWeight.Bold, fontSize = 15.sp, modifier = Modifier.padding(start = 4.dp, bottom = 12.dp))
            Row(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(v.card).border(1.dp, v.line, RoundedCornerShape(14.dp))
                    .clickable { vm.newChat(); onClose() }.padding(14.dp),
                verticalAlignment = Alignment.CenterVertically
            ) { Text(if (vm.mode == "code") "+  Новый код-чат" else "+  Новый чат", color = v.text, fontWeight = FontWeight.SemiBold) }
            Spacer(Modifier.height(10.dp))
            Row(Modifier.fillMaxWidth().background(v.card, RoundedCornerShape(12.dp)).padding(3.dp)) {
                for ((k, t) in listOf("all" to "Все", "chat" to "Чаты", "code" to "Code")) {
                    Box(
                        Modifier.weight(1f).clip(RoundedCornerShape(9.dp)).background(if (filter == k) v.card2 else v.card)
                            .clickable { filter = k }.padding(vertical = 8.dp),
                        contentAlignment = Alignment.Center
                    ) { Text(t, color = if (filter == k) v.text else v.muted, fontSize = 13.sp) }
                }
            }
            Spacer(Modifier.height(8.dp))
            BasicTextField(
                value = query, onValueChange = { query = it }, singleLine = true,
                textStyle = TextStyle(color = v.text, fontSize = 14.sp), cursorBrush = SolidColor(v.accent),
                modifier = Modifier.fillMaxWidth(),
                decorationBox = { inner ->
                    Box(Modifier.fillMaxWidth().background(v.card, RoundedCornerShape(12.dp)).border(1.dp, v.line, RoundedCornerShape(12.dp)).padding(12.dp)) {
                        if (query.isEmpty()) Text("Поиск по чатам", color = v.muted, fontSize = 14.sp)
                        inner()
                    }
                }
            )
            Spacer(Modifier.height(8.dp))
            LazyColumn(Modifier.weight(1f)) {
                if (list.isEmpty()) item { Text("Пока нет сохранённых чатов", color = v.muted, fontSize = 13.sp, modifier = Modifier.padding(8.dp)) }
                items(list, key = { it.id }) { s ->
                    Row(
                        Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp))
                            .background(if (s.id == vm.curId) v.card else v.bg)
                            .clickable { vm.openSession(s.id); onClose() }.padding(start = 10.dp, top = 4.dp, bottom = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(s.title, color = v.text, fontSize = 14.5.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
                        Text(
                            if (s.mode == "code") "CODE" else "ЧАТ", fontSize = 10.sp,
                            color = if (s.mode == "code") v.onAccent else v.muted,
                            modifier = Modifier.padding(horizontal = 4.dp)
                                .background(if (s.mode == "code") v.accent else v.card2, RoundedCornerShape(10.dp))
                                .padding(horizontal = 7.dp, vertical = 2.dp)
                        )
                        Text("✕", color = v.muted, modifier = Modifier.clickable { vm.deleteSession(s.id) }.padding(10.dp))
                    }
                }
            }
            HorizontalDivider(color = v.line, modifier = Modifier.padding(vertical = 8.dp))
            DrawerAction(v, if (vm.mode == "code") "Вернуться в обычный чат" else "VKTR Code", if (vm.mode == "code") "" else "") {
                vm.setMode(if (vm.mode == "code") "chat" else "code", false); onClose()
            }
            DrawerAction(v, "Скачать проект в ZIP" + if (vm.files.isNotEmpty()) " (" + vm.files.size + ")" else "", "") {
                vm.zipProject(ctx); onClose()
            }
            DrawerAction(v, "Нейросети и ключи", "") { onClose(); onProviders() }
            Row(Modifier.fillMaxWidth().padding(top = 8.dp, start = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("Тема", color = v.muted, fontSize = 13.sp, modifier = Modifier.weight(1f))
                for ((k, p) in Palettes) {
                    Box(
                        Modifier.padding(start = 10.dp).size(30.dp).clip(CircleShape).background(p.bg)
                            .border(2.dp, if (vm.theme == k) p.accent else v.line, CircleShape)
                            .clickable { vm.setTheme(k) }
                    )
                }
            }
        }
    }
}

@Composable
private fun DrawerAction(v: VColors, title: String, hint: String, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).clickable(onClick = onClick).padding(12.dp)) {
        Text(title, color = v.text, fontSize = 14.5.sp, modifier = Modifier.weight(1f))
        if (hint.isNotEmpty()) Text(hint, color = v.muted, fontSize = 12.sp)
    }
}

private data class Preset(val name: String, val base: String, val model: String, val vision: Boolean)

private val PRESETS = listOf(
    Preset("Groq", "https://api.groq.com/openai/v1", "openai/gpt-oss-120b", false),
    Preset("Groq · фото", "https://api.groq.com/openai/v1", "meta-llama/llama-4-scout-17b-16e-instruct", true),
    Preset("OpenRouter", "https://openrouter.ai/api/v1", "openrouter/free", true),
    Preset("Mistral", "https://api.mistral.ai/v1", "mistral-small-latest", false),
    Preset("Gemini", "https://generativelanguage.googleapis.com/v1beta/openai", "gemini-2.0-flash", true),
    Preset("Свой сервер", "", "", false)
)

@Composable
fun ProvidersDialog(vm: ChatVM, v: VColors, onDismiss: () -> Unit) {
    var editing by remember { mutableStateOf<Provider?>(null) }
    val ed = editing
    if (ed != null) {
        ProviderEditor(ed, onSave = { vm.saveProvider(it); editing = null }, onCancel = { editing = null })
        return
    }
    AlertDialog(
        onDismissRequest = onDismiss,
        confirmButton = { TextButton(onClick = onDismiss) { Text("Готово") } },
        title = { Text("Нейросети") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                if (vm.providers.isEmpty()) Text("Пока ничего не подключено. Выберите вариант ниже и вставьте ключ.", fontSize = 14.sp)
                for (p in vm.providers) {
                    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            (if (p.id == vm.activeId) "● " else "○ ") + p.name,
                            modifier = Modifier.weight(1f).clickable { vm.setActive(p.id) }.padding(vertical = 8.dp)
                        )
                        Text("Изм.", modifier = Modifier.clickable { editing = p }.padding(8.dp), fontSize = 13.sp)
                        Text("✕", modifier = Modifier.clickable { vm.removeProvider(p.id) }.padding(8.dp))
                    }
                }
                Text("Добавить", fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 12.dp, bottom = 4.dp))
                for (pr in PRESETS) {
                    Text(
                        pr.name,
                        modifier = Modifier.fillMaxWidth().clickable {
                            editing = Provider(newId(), pr.name, pr.base, pr.model, "", pr.vision)
                        }.padding(vertical = 8.dp)
                    )
                }
                Text("Ключи можно вставить несколько (по одному на строку): при лимите приложение само возьмёт следующий.", fontSize = 12.sp, modifier = Modifier.padding(top = 10.dp))
                OutlinedTextField(
                    value = vm.userName, onValueChange = { vm.setName(it) }, singleLine = true,
                    label = { Text("Как к вам обращаться") }, modifier = Modifier.fillMaxWidth().padding(top = 10.dp)
                )
            }
        }
    )
}

@Composable
fun ProviderEditor(p: Provider, onSave: (Provider) -> Unit, onCancel: () -> Unit) {
    var name by remember { mutableStateOf(p.name) }
    var base by remember { mutableStateOf(p.base) }
    var model by remember { mutableStateOf(p.model) }
    var keys by remember { mutableStateOf(p.keys) }
    var vision by remember { mutableStateOf(p.vision) }
    AlertDialog(
        onDismissRequest = onCancel,
        confirmButton = {
            TextButton(onClick = { onSave(Provider(p.id, name.trim(), base.trim(), model.trim(), keys.trim(), vision)) }) { Text("Сохранить") }
        },
        dismissButton = { TextButton(onClick = onCancel) { Text("Отмена") } },
        title = { Text("Нейросеть") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("Название") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = base, onValueChange = { base = it }, label = { Text("Адрес API (…/v1)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = model, onValueChange = { model = it }, label = { Text("Модель") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = keys, onValueChange = { keys = it }, label = { Text("Ключи (по одному на строку)") }, minLines = 3, modifier = Modifier.fillMaxWidth())
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Понимает фото", modifier = Modifier.weight(1f))
                    Switch(checked = vision, onCheckedChange = { vision = it })
                }
            }
        }
    )
}
