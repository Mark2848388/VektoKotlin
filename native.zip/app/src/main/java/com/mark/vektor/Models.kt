package com.mark.vektor

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

data class Provider(
    val id: String,
    val name: String,
    val base: String,
    val model: String,
    val keys: String,
    val vision: Boolean
) {
    fun keyList(): List<String> = keys.split(Regex("[\\s,;]+")).filter { it.length > 3 }

    fun toJson(): JSONObject = JSONObject()
        .put("id", id).put("name", name).put("base", base)
        .put("model", model).put("keys", keys).put("vision", vision)

    companion object {
        fun fromJson(j: JSONObject) = Provider(
            j.optString("id"), j.optString("name"), j.optString("base"),
            j.optString("model"), j.optString("keys"), j.optBoolean("vision")
        )
    }
}

data class CodeFile(val lang: String, val code: String)

data class Msg(
    val role: String,
    val text: String,
    val hidden: String = "",
    val atts: List<String> = emptyList()
) {
    fun toJson(): JSONObject = JSONObject()
        .put("role", role).put("text", text).put("hidden", hidden).put("atts", JSONArray(atts))

    companion object {
        fun fromJson(j: JSONObject): Msg {
            val a = j.optJSONArray("atts")
            val list = ArrayList<String>()
            if (a != null) for (i in 0 until a.length()) list.add(a.optString(i))
            return Msg(j.optString("role"), j.optString("text"), j.optString("hidden"), list)
        }
    }
}

data class Session(
    val id: String,
    val mode: String,
    val title: String,
    val ts: Long,
    val msgs: List<Msg>,
    val files: Map<String, CodeFile>,
    val fname: String
) {
    fun toJson(): JSONObject {
        val m = JSONArray()
        for (x in msgs.takeLast(80)) m.put(x.toJson())
        val f = JSONObject()
        for ((k, v) in files) f.put(k, JSONObject().put("lang", v.lang).put("code", v.code))
        return JSONObject().put("id", id).put("mode", mode).put("title", title).put("ts", ts)
            .put("msgs", m).put("files", f).put("fname", fname)
    }

    companion object {
        fun fromJson(j: JSONObject): Session {
            val msgs = ArrayList<Msg>()
            val ma = j.optJSONArray("msgs")
            if (ma != null) for (i in 0 until ma.length()) msgs.add(Msg.fromJson(ma.getJSONObject(i)))
            val files = LinkedHashMap<String, CodeFile>()
            val fo = j.optJSONObject("files")
            if (fo != null) {
                val it = fo.keys()
                while (it.hasNext()) {
                    val k = it.next()
                    val o = fo.getJSONObject(k)
                    files[k] = CodeFile(o.optString("lang"), o.optString("code"))
                }
            }
            return Session(
                j.optString("id"), j.optString("mode", "chat"), j.optString("title"),
                j.optLong("ts"), msgs, files, j.optString("fname")
            )
        }
    }
}

class Store(private val ctx: Context) {
    private val sp = ctx.getSharedPreferences("vektor", Context.MODE_PRIVATE)
    private val sessionsFile get() = File(ctx.filesDir, "sessions.json")

    fun str(key: String, def: String): String = sp.getString(key, def) ?: def
    fun putStr(key: String, v: String) { sp.edit().putString(key, v).apply() }
    fun bool(key: String, def: Boolean): Boolean = sp.getBoolean(key, def)
    fun putBool(key: String, v: Boolean) { sp.edit().putBoolean(key, v).apply() }

    fun loadProviders(): MutableList<Provider> {
        val out = ArrayList<Provider>()
        try {
            val a = JSONArray(str("providers", "[]"))
            for (i in 0 until a.length()) out.add(Provider.fromJson(a.getJSONObject(i)))
        } catch (_: Exception) {}
        return out
    }

    fun saveProviders(list: List<Provider>) {
        val a = JSONArray()
        for (p in list) a.put(p.toJson())
        putStr("providers", a.toString())
    }

    fun loadSessions(): MutableList<Session> {
        val out = ArrayList<Session>()
        try {
            if (sessionsFile.exists()) {
                val a = JSONArray(sessionsFile.readText())
                for (i in 0 until a.length()) out.add(Session.fromJson(a.getJSONObject(i)))
            }
        } catch (_: Exception) {}
        return out
    }

    fun saveSessions(list: List<Session>) {
        try {
            val a = JSONArray()
            for (s in list.take(40)) a.put(s.toJson())
            sessionsFile.writeText(a.toString())
        } catch (_: Exception) {}
    }
}
