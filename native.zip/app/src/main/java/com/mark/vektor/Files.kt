package com.mark.vektor

import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.provider.OpenableColumns
import android.util.Base64
import androidx.core.content.FileProvider
import androidx.exifinterface.media.ExifInterface
import java.io.ByteArrayOutputStream
import java.io.File
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

class Att(
    val kind: String,          // image | zip | doc | text | bin
    val name: String,
    val size: Long,
    val dataUrl: String? = null,
    val thumb: Bitmap? = null,
    val ctx: String = "",
    val files: List<Pair<String, String>> = emptyList()
)

object Files {
    private val TEXT_EXT = setOf(
        "txt", "md", "markdown", "rst", "json", "jsonc", "csv", "tsv", "xml", "html", "htm", "css", "scss", "sass", "less",
        "js", "mjs", "cjs", "jsx", "ts", "tsx", "vue", "svelte", "py", "java", "kt", "kts", "gradle", "c", "h", "cpp", "cc",
        "hpp", "cs", "go", "rs", "php", "rb", "swift", "dart", "lua", "r", "sh", "bash", "bat", "ps1", "sql", "yml", "yaml",
        "toml", "ini", "cfg", "conf", "env", "properties", "log", "tex", "srt", "vtt", "gitignore", "editorconfig", "svg", "iml"
    )
    private val TEXT_NAMES = Regex("(^|/)(dockerfile|makefile|readme|license|procfile|gemfile|\\.gitignore|\\.env[\\w.]*)$", RegexOption.IGNORE_CASE)
    private val SKIP_DIR = Regex("(^|/)(node_modules|\\.git|__pycache__|\\.idea|\\.vscode|build|dist|\\.gradle|venv|\\.venv|target|out|\\.next)/", RegexOption.IGNORE_CASE)
    const val CTX_MAX = 50000
    const val ZIP_BUDGET = 70000

    fun fmtSize(n: Long): String = when {
        n < 1024 -> "$n Б"
        n < 1048576 -> String.format("%.1f КБ", n / 1024.0)
        else -> String.format("%.1f МБ", n / 1048576.0)
    }

    private fun block(name: String, text: String, max: Int = CTX_MAX): String =
        "=== ФАЙЛ: $name (${text.length} симв.) ===\n" + text.take(max) +
            (if (text.length > max) "\n[… обрезано, всего ${text.length} симв.]" else "") + "\n=== КОНЕЦ ФАЙЛА ==="

    private fun isTextName(name: String): Boolean {
        val ext = name.substringAfterLast('.', "").lowercase()
        return ext in TEXT_EXT || TEXT_NAMES.containsMatchIn(name)
    }

    fun nameOf(ctx: Context, uri: Uri): String {
        try {
            ctx.contentResolver.query(uri, null, null, null, null)?.use { c ->
                val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (i >= 0 && c.moveToFirst()) return c.getString(i) ?: "файл"
            }
        } catch (_: Exception) {}
        return uri.lastPathSegment?.substringAfterLast('/') ?: "файл"
    }

    private fun sizeOf(ctx: Context, uri: Uri): Long {
        try {
            ctx.contentResolver.query(uri, null, null, null, null)?.use { c ->
                val i = c.getColumnIndex(OpenableColumns.SIZE)
                if (i >= 0 && c.moveToFirst()) return c.getLong(i)
            }
        } catch (_: Exception) {}
        return 0L
    }

    private fun toDataUrl(bmp: Bitmap, quality: Int = 82): String {
        val bo = ByteArrayOutputStream()
        bmp.compress(Bitmap.CompressFormat.JPEG, quality, bo)
        return "data:image/jpeg;base64," + Base64.encodeToString(bo.toByteArray(), Base64.NO_WRAP)
    }

    private fun scaled(bmp: Bitmap, max: Int): Bitmap {
        val k = minOf(1f, max.toFloat() / maxOf(bmp.width, bmp.height))
        if (k >= 1f) return bmp
        return Bitmap.createScaledBitmap(bmp, (bmp.width * k).toInt().coerceAtLeast(1), (bmp.height * k).toInt().coerceAtLeast(1), true)
    }

    private fun readImage(ctx: Context, uri: Uri, name: String, size: Long): Att {
        val cr = ctx.contentResolver
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        cr.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
        var sample = 1
        while (maxOf(bounds.outWidth, bounds.outHeight) / sample > 2600) sample *= 2
        val opts = BitmapFactory.Options().apply { inSampleSize = sample }
        var bmp = cr.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
            ?: throw Exception("не удалось открыть изображение")
        try {
            val orient = cr.openInputStream(uri)?.use {
                ExifInterface(it).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)
            } ?: ExifInterface.ORIENTATION_NORMAL
            val deg = when (orient) {
                ExifInterface.ORIENTATION_ROTATE_90 -> 90f
                ExifInterface.ORIENTATION_ROTATE_180 -> 180f
                ExifInterface.ORIENTATION_ROTATE_270 -> 270f
                else -> 0f
            }
            if (deg != 0f) {
                val m = Matrix().apply { postRotate(deg) }
                bmp = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, true)
            }
        } catch (_: Exception) {}
        val big = scaled(bmp, 1280)
        return Att("image", name, size, dataUrl = toDataUrl(big), thumb = scaled(big, 200))
    }

    private fun readPdf(ctx: Context, uri: Uri, name: String): List<Att> {
        val out = ArrayList<Att>()
        val pfd = ctx.contentResolver.openFileDescriptor(uri, "r") ?: throw Exception("не удалось открыть PDF")
        pfd.use {
            val r = PdfRenderer(it)
            try {
                val n = minOf(r.pageCount, 6)
                for (i in 0 until n) {
                    val page = r.openPage(i)
                    try {
                        val w = 1000
                        val h = (w.toFloat() * page.height / page.width).toInt().coerceAtLeast(1)
                        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
                        bmp.eraseColor(Color.WHITE)
                        page.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                        out.add(Att("image", "$name, стр. ${i + 1}", 0, dataUrl = toDataUrl(bmp, 80), thumb = scaled(bmp, 200)))
                    } finally {
                        page.close()
                    }
                }
            } finally {
                r.close()
            }
        }
        return out
    }

    private fun xmlText(xml: String, paraEnd: String): String {
        var s = if (paraEnd.isNotEmpty()) xml.replace(paraEnd, "\n") else xml
        s = s.replace(Regex("<[^>]+>"), "")
        return s.replace("&lt;", "<").replace("&gt;", ">").replace("&quot;", "\"").replace("&apos;", "'").replace("&amp;", "&")
            .replace(Regex("\n{3,}"), "\n\n").trim()
    }

    private fun readZipEntries(ctx: Context, uri: Uri, wanted: (String) -> Boolean, limit: Int): Pair<List<String>, Map<String, String>> {
        val names = ArrayList<String>()
        val data = LinkedHashMap<String, String>()
        var total = 0L
        ctx.contentResolver.openInputStream(uri)?.use { raw ->
            ZipInputStream(raw).use { z ->
                var e: ZipEntry? = z.nextEntry
                var count = 0
                while (e != null && count < 2000) {
                    val n = e.name
                    if (!e.isDirectory) {
                        count++
                        names.add(n)
                        if (wanted(n) && total < 8_000_000L) {
                            val bo = ByteArrayOutputStream()
                            val buf = ByteArray(8192)
                            var read = 0
                            while (true) {
                                val k = z.read(buf)
                                if (k < 0) break
                                read += k
                                if (read <= limit) bo.write(buf, 0, k)
                            }
                            if (read <= limit) {
                                total += read
                                data[n] = bo.toString("UTF-8")
                            }
                        }
                    }
                    e = z.nextEntry
                }
            }
        }
        return Pair(names, data)
    }

    private fun readDoc(ctx: Context, uri: Uri, name: String, size: Long): Att {
        val ext = name.substringAfterLast('.', "").lowercase()
        val (_, d) = readZipEntries(ctx, uri, { n ->
            n == "word/document.xml" || n.matches(Regex("ppt/slides/slide\\d+\\.xml")) || n == "xl/sharedStrings.xml" ||
                n.matches(Regex("xl/worksheets/sheet\\d+\\.xml")) || n == "content.xml"
        }, 6_000_000)
        var text = ""
        when (ext) {
            "docx" -> text = xmlText(d["word/document.xml"] ?: "", "</w:p>")
            "pptx" -> {
                val keys = d.keys.filter { it.startsWith("ppt/slides/") }
                    .sortedBy { Regex("\\d+").find(it)?.value?.toIntOrNull() ?: 0 }
                val sb = StringBuilder()
                var i = 0
                for (k in keys) { i++; sb.append("--- Слайд $i ---\n").append(xmlText(d[k] ?: "", "</a:p>")).append("\n") }
                text = sb.toString()
            }
            "xlsx" -> {
                val ss = Regex("<si>(.*?)</si>", RegexOption.DOT_MATCHES_ALL).findAll(d["xl/sharedStrings.xml"] ?: "")
                    .map { xmlText(it.groupValues[1], "") }.toList()
                val sb = StringBuilder()
                var i = 0
                for (k in d.keys.filter { it.startsWith("xl/worksheets/") }) {
                    i++
                    sb.append("--- Лист $i ---\n")
                    for (row in Regex("<row\\b[^>]*>(.*?)</row>", RegexOption.DOT_MATCHES_ALL).findAll(d[k] ?: "").take(500)) {
                        val cells = Regex("<c\\b([^>]*)>(.*?)</c>", RegexOption.DOT_MATCHES_ALL).findAll(row.groupValues[1]).map { c ->
                            val v = Regex("<v>(.*?)</v>", RegexOption.DOT_MATCHES_ALL).find(c.groupValues[2])?.groupValues?.get(1) ?: xmlText(c.groupValues[2], "")
                            if (c.groupValues[1].contains("t=\"s\"")) (ss.getOrNull(v.toIntOrNull() ?: -1) ?: "") else v
                        }.toList()
                        sb.append(cells.joinToString("\t")).append("\n")
                    }
                }
                text = sb.toString()
            }
            else -> text = xmlText((d["content.xml"] ?: "").replace("</table:table-cell>", "\t").replace("</table:table-row>", "\n").replace("</text:h>", "\n"), "</text:p>")
        }
        text = text.trim()
        return Att("doc", name, size, ctx = if (text.isEmpty()) "=== ФАЙЛ $name: текст не найден ===" else block(name, text))
    }

    private fun readZip(ctx: Context, uri: Uri, name: String, size: Long): Att {
        val (names, data) = readZipEntries(ctx, uri, { n -> !SKIP_DIR.containsMatchIn(n) && isTextName(n) }, 250_000)
        val ents = names.filter { !SKIP_DIR.containsMatchIn(it) }
        val roots = ents.map { it.substringBefore('/') }.toSet()
        val strip = if (roots.size == 1 && ents.all { it.contains('/') }) roots.first() + "/" else ""
        fun rel(n: String) = if (strip.isNotEmpty() && n.startsWith(strip)) n.substring(strip.length) else n
        val tree = ents.take(300).joinToString("\n") { rel(it) }
        fun rank(n: String) = if (Regex("(^|/)(readme|package\\.json|requirements\\.txt|pom\\.xml|build\\.gradle|manifest\\.json|index\\.html)", RegexOption.IGNORE_CASE).containsMatchIn(rel(n))) 0 else 1
        val sorted = data.entries.filter { !it.value.take(2000).contains('\u0000') }.sortedWith(compareBy({ rank(it.key) }, { it.value.length }))
        val files = ArrayList<Pair<String, String>>()
        var budget = ZIP_BUDGET
        for (e in sorted) {
            if (budget <= 0) break
            files.add(Pair(rel(e.key), e.value))
            budget -= e.value.length
        }
        val ctxText = "=== АРХИВ: $name, файлов: ${ents.size} ===\nСтруктура:\n$tree\n\n" +
            files.joinToString("\n") { block(it.first, it.second, 20000) } +
            (if (ents.size > files.size) "\n(Не прочитано как текст: ${ents.size - files.size} — бинарные, большие или служебные файлы.)" else "")
        return Att("zip", name, size, ctx = ctxText, files = files)
    }

    /** Читает один выбранный файл; PDF превращается в картинки страниц. */
    fun read(ctx: Context, uri: Uri): List<Att> {
        val name = nameOf(ctx, uri)
        val size = sizeOf(ctx, uri)
        val mime = ctx.contentResolver.getType(uri) ?: ""
        val lower = name.lowercase()
        return when {
            mime.startsWith("image/") || Regex(".*\\.(jpe?g|png|webp|gif|bmp|heic|heif|avif)$").matches(lower) -> listOf(readImage(ctx, uri, name, size))
            mime == "application/pdf" || lower.endsWith(".pdf") -> readPdf(ctx, uri, name)
            Regex(".*\\.(zip|jar|apk|aar|war)$").matches(lower) || mime == "application/zip" -> listOf(readZip(ctx, uri, name, size))
            Regex(".*\\.(docx|pptx|xlsx|odt|odp|ods)$").matches(lower) -> listOf(readDoc(ctx, uri, name, size))
            else -> {
                val bytes = ctx.contentResolver.openInputStream(uri)?.use { it.readBytes() } ?: ByteArray(0)
                if (bytes.size <= 2_000_000 && !bytes.take(4096).contains(0.toByte())) {
                    val t = String(bytes, Charsets.UTF_8)
                    listOf(Att("text", name, size, ctx = block(name, t), files = listOf(Pair(name, t))))
                } else {
                    listOf(Att("bin", name, size, ctx = "=== ФАЙЛ $name (${fmtSize(size)}): двоичный файл, содержимое не читается. ==="))
                }
            }
        }
    }

    fun zipBytes(root: String, files: Map<String, CodeFile>): ByteArray {
        val bo = ByteArrayOutputStream()
        ZipOutputStream(bo).use { z ->
            for ((p, f) in files) {
                z.putNextEntry(ZipEntry("$root/$p"))
                z.write(f.code.toByteArray(Charsets.UTF_8))
                z.closeEntry()
            }
        }
        return bo.toByteArray()
    }

    /** Сохраняет в «Загрузки/Vektor» (Android 10+) или в папку приложения. Возвращает описание места. */
    fun saveDownload(ctx: Context, name: String, mime: String, bytes: ByteArray): String {
        if (Build.VERSION.SDK_INT >= 29) {
            val cv = ContentValues().apply {
                put(MediaStore.Downloads.DISPLAY_NAME, name)
                put(MediaStore.Downloads.MIME_TYPE, mime)
                put(MediaStore.Downloads.RELATIVE_PATH, "Download/Vektor")
            }
            val uri = ctx.contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv)
            if (uri != null) {
                ctx.contentResolver.openOutputStream(uri)?.use { it.write(bytes) }
                return "Загрузки/Vektor/$name"
            }
        }
        val dir = ctx.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS) ?: ctx.filesDir
        File(dir, name).writeBytes(bytes)
        return File(dir, name).absolutePath
    }

    fun shareFile(ctx: Context, name: String, mime: String, bytes: ByteArray) {
        val dir = File(ctx.cacheDir, "images").apply { mkdirs() }
        val f = File(dir, name)
        f.writeBytes(bytes)
        val u = FileProvider.getUriForFile(ctx, ctx.packageName + ".files", f)
        val send = Intent(Intent.ACTION_SEND).apply {
            type = mime
            putExtra(Intent.EXTRA_STREAM, u)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        ctx.startActivity(Intent.createChooser(send, name).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    fun shareText(ctx: Context, text: String) {
        val i = Intent(Intent.ACTION_SEND).apply { type = "text/plain"; putExtra(Intent.EXTRA_TEXT, text) }
        ctx.startActivity(Intent.createChooser(i, "Поделиться").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    fun newCameraUri(ctx: Context): Uri {
        val dir = File(ctx.cacheDir, "images").apply { mkdirs() }
        val f = File(dir, "cam_" + System.currentTimeMillis() + ".jpg")
        return FileProvider.getUriForFile(ctx, ctx.packageName + ".files", f)
    }
}
