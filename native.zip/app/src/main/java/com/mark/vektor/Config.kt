package com.mark.vektor

object Config {
    const val VERSION = "5.0"

    // Адрес вашего облачного прокси (Cloudflare Worker), например "https://vektor.example.workers.dev/v1".
    // Если заполнить, приложение само подключит «Vektor AI», и пользователям не нужны свои ключи.
    const val CLOUD_URL = ""
}
