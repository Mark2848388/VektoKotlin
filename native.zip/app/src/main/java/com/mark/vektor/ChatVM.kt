package com.mark.vektor

import android.app.Application
import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.atomic.AtomicInteger

fun newId(): String = "c" + System.currentTimeMillis() + (0..999).random()

class UserPayload(val content: Any, val vision: Boolean, val digest: String)

class ChatVM(app: Application) : AndroidViewModel(app) {
    private val store = Store(app)

    val providers = mutableStateListOf<Provider>()
    var activeId by mutableStateOf("")
    var theme by mutableStateOf("warm")
    var userName by mutableStateOf("")

    val sessions = mutableStateListOf<Session>()
    val messages = mutableStateListOf<Msg>()
    val files = mutableStateMapOf<String, CodeFile>()
    var fname by mutableStateOf("")
    var curId by mutableStateOf(newId())
    var mode by mutableStateOf("chat")

    var input by mutableStateOf("")
    val atts = mutableStateListOf<Att>()
    var live by mutableStateOf<String?>(null)
    var busy by mutableStateOf(false)
    var status by mutableStateOf("")

    val events = MutableSharedFlow<String>(extraBufferCapacity = 8)
    private var job: Job? = null

    @Volatile private var target = ""
    @Volatile private var netDone = false

    init {
        providers.addAll(store.loadProviders())
        if (Config.CLOUD_URL.isNotBlank() && providers.none { it.id == "cloud" }) {
            providers.add(0, Provider("cloud", "Vektor AI", Config.CLOUD_URL, "openai/gpt-oss-120b", "vektor", true))
            store.saveProviders(providers.toList())
        }
        activeId = store.str("active", providers.firstOrNull()?.id ?: "")
        if (providers.none { it.id == activeId }) activeId = providers.firstOrNull()?.id ?: ""
        theme = store.str("theme", "warm")
        userName = store.str("name", "")
        sessions.addAll(store.loadSessions())
        mode = store.str("mode", "chat")
        val last = sessions.find { it.id == store.str("cur_$mode", "") && it.mode == mode }
        if (last != null) { curId = last.id; loadSession(last) }
    }

    fun emit(s: String) { events.tryEmit(s) }

    // ---------- настройки ----------
    fun setTheme(t: String) { theme = t; store.putStr("theme", t) }
    fun setName(n: String) { userName = n; store.putStr("name", n) }
    fun setActive(id: String) { activeId = id; store.putStr("active", id) }

    fun saveProvider(p: Provider) {
        val i = providers.indexOfFirst { it.id == p.id }
        if (i >= 0) providers[i] = p else providers.add(p)
        store.saveProviders(providers.toList())
        if (activeId.isBlank() || providers.none { it.id == activeId }) setActive(p.id)
    }

    fun removeProvider(id: String) {
        providers.removeAll { it.id == id }
        store.saveProviders(providers.toList())
        if (activeId == id) setActive(providers.firstOrNull()?.id ?: "")
    }

    fun activeName(): String = providers.find { it.id == activeId }?.name ?: "Нет ИИ"

    // ---------- чаты ----------
    private fun titleOf(): String {
        val u = messages.firstOrNull { it.role == "user" }?.text ?: ""
        val t = u.replace(Regex("\\s+"), " ").trim().take(44)
        return if (t.isNotEmpty()) t else if (mode == "code") "Новый код-чат" else "Новый чат"
    }

    fun saveCurrent() {
        sessions.removeAll { it.id == curId }
        if (messages.any { it.role == "user" }) {
            sessions.add(0, Session(curId, mode, titleOf(), System.currentTimeMillis(), messages.toList(), files.toMap(), fname))
        }
        while (sessions.size > 40) sessions.removeAt(sessions.size - 1)
        store.saveSessions(sessions.toList())
        store.putStr("cur_$mode", curId)
        store.putStr("mode", mode)
    }

    private fun loadSession(s: Session) {
        messages.clear(); messages.addAll(s.msgs)
        files.clear(); files.putAll(s.files)
        fname = s.fname
    }

    private fun clearCurrent() {
        messages.clear(); files.clear(); fname = ""; atts.clear(); input = ""
    }

    fun newChat() {
        if (busy) return
        saveCurrent()
        curId = newId()
        clearCurrent()
    }

    fun openSession(id: String) {
        if (busy || id == curId) return
        saveCurrent()
        val s = sessions.find { it.id == id } ?: return
        mode = s.mode
        curId = s.id
        loadSession(s)
        store.putStr("mode", mode)
    }

    fun deleteSession(id: String) {
        if (busy) return
        sessions.removeAll { it.id == id }
        store.saveSessions(sessions.toList())
        if (id == curId) { curId = newId(); clearCurrent() }
    }

    fun setMode(m: String, fresh: Boolean) {
        if (busy || (m == mode && !fresh)) return
        saveCurrent()
        mode = m
        val last = store.str("cur_$m", "")
        val s = if (fresh) null else sessions.find { it.id == last && it.mode == m }
        if (s != null) { curId = s.id; loadSession(s) } else { curId = newId(); clearCurrent() }
        store.putStr("mode", m)
    }

    // ---------- вложения ----------
    fun addUris(ctx: Context, uris: List<android.net.Uri>) {
        viewModelScope.launch(Dispatchers.IO) {
            var added = 0
            for (u in uris) {
                try {
                    for (a in Files.read(ctx, u)) {
                        if (atts.size >= 12) { emit("Не больше 12 вложений за раз"); break }
                        if (a.kind == "image" && atts.count { it.kind == "image" } >= 8) { emit("Не больше 8 фото за раз"); continue }
                        atts.add(a); added++
                    }
                } catch (e: Exception) {
                    emit("Не удалось прочитать файл: " + (e.message ?: ""))
                }
            }
            if (added > 0) emit("Прикреплено: $added")
        }
    }

    fun removeAtt(i: Int) { if (i in atts.indices) atts.removeAt(i) }

    // ---------- ZIP ----------
    fun zipProject(ctx: Context): Boolean {
        if (files.isEmpty()) { emit("Пока нет файлов проекта"); return false }
        val root = fname.ifBlank { "vektor-project" }.replace(Regex("[^A-Za-z0-9._-]+"), "-")
        return try {
            val bytes = Files.zipBytes(root, files.toMap())
            val where = Files.saveDownload(ctx, "$root.zip", "application/zip", bytes)
            emit("ZIP сохранён: $where")
            Files.shareFile(ctx, "$root.zip", "application/zip", bytes)
            true
        } catch (e: Exception) {
            emit("Не удалось собрать ZIP: " + (e.message ?: ""))
            false
        }
    }

    // ---------- отправка ----------
    fun stop() {
        job?.cancel()
        busy = false
        live = null
        status = ""
        messages.add(Msg("sys", "Остановлено"))
    }

    fun send() {
        if (busy) return
        val raw = input.trim()
        if (raw.isEmpty() && atts.isEmpty()) return
        val taken = atts.toList()
        val text = when {
            raw.isNotEmpty() -> raw
            mode == "code" -> "Изучи вложенные файлы и кратко опиши структуру проекта и что можно улучшить"
            taken.all { it.kind == "image" } -> "Опиши, что на изображении"
            else -> "Изучи вложения и кратко расскажи, что в них"
        }
        input = ""
        atts.clear()

        val s = text.lowercase()
        val build = Regex("(сделай|создай|напиши|построй|разработай|сгенерируй|собери)\\s").containsMatchIn("$s ")
        val soft = Regex("(приложени|сайт|игр[уаы]|скрипт|программ|бот[аы]?\\b|калькулятор|страниц|проект|код\\b|апк|api|интерфейс|лендинг)").containsMatchIn(s)
        val wantPack = Regex("(запакуй|упакуй|заархивируй|архивируй)").containsMatchIn(s) ||
            (Regex("(zip|зип|архив)").containsMatchIn(s) && Regex("(скачать|скачай|дай|собери|сделай|создай|отправь)").containsMatchIn(s))
        var autoZip = false
        if (wantPack) {
            val packOnly = Regex("^(и )?(запакуй|упакуй|заархивируй|архивируй)").containsMatchIn(s) ||
                Regex("^(сделай|создай|собери|дай|скачай)( мне)? (zip|зип|архив)").containsMatchIn(s) ||
                (!build && files.isNotEmpty())
            if (packOnly || !build) {
                messages.add(Msg("user", text))
                zipProject(getApplication<Application>())
                saveCurrent()
                return
            }
            if (mode != "code") setMode("code", true)
            autoZip = true
        } else if (mode != "code" && build && soft) {
            setMode("code", true)
        } else if (mode != "code" && taken.any { it.kind == "zip" || it.kind == "text" } &&
            Regex("(исправь|доработай|добавь|измени|перепиши|рефактор|найди ошибк|найди баг|оптимизируй|сделай|напиши)").containsMatchIn(s)
        ) {
            setMode("code", true)
        }

        messages.add(Msg("user", text, atts = taken.map { it.name }))
        busy = true
        status = ""
        job = viewModelScope.launch {
            try {
                if (mode == "code") runCode(text, taken, autoZip) else runChat(text, taken)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                messages.add(Msg("sys", "Ошибка: " + (e.message ?: e.javaClass.simpleName)))
            } finally {
                busy = false
                live = null
                status = ""
                saveCurrent()
            }
        }
    }

    private fun sysPrompt(): String {
        val date = SimpleDateFormat("d MMMM yyyy, HH:mm", Locale("ru")).format(Date())
        val who = if (userName.isNotBlank()) " Обращайся к пользователю по имени: «$userName»." else ""
        return "Ты Вектор — личный ИИ-ассистент в приложении на телефоне. Отвечай по-русски, спокойно, умно и лаконично, с лёгким юмором.$who " +
            "Сейчас $date. " + Code.CHAT_SUFFIX
    }

    private fun buildUser(text: String, taken: List<Att>): UserPayload {
        if (taken.isEmpty()) return UserPayload(text, false, "")
        var left = 80000
        val ctx = StringBuilder()
        for (a in taken) {
            if (a.kind != "image" && a.ctx.isNotEmpty()) {
                val c = a.ctx.take(maxOf(0, left))
                ctx.append(c).append("\n\n")
                left -= c.length
            }
        }
        val ctxText = ctx.toString()
        val body = (if (ctxText.isNotEmpty()) "Вложения пользователя:\n" + ctxText + "Запрос пользователя: " else "") + text
        val digest = "[вложения: " + taken.joinToString(", ") { it.name } + "]" + (if (ctxText.isNotEmpty()) "\n" + ctxText.take(9000) else "")
        val imgs = taken.filter { it.kind == "image" && it.dataUrl != null }
        if (imgs.isEmpty()) return UserPayload(body, false, digest)
        val arr = JSONArray()
        arr.put(JSONObject().put("type", "text").put("text", body))
        for (im in imgs) {
            arr.put(JSONObject().put("type", "image_url").put("image_url", JSONObject().put("url", im.dataUrl)))
        }
        return UserPayload(arr, true, digest)
    }

    /** Показывает ответ плавно, по буквам, пока он приходит по сети. */
    private suspend fun streamAnswer(call: ((String) -> Unit) -> String): String = coroutineScope {
        target = ""
        netDone = false
        val shown = AtomicInteger(0)
        live = ""
        val ticker = launch {
            while (isActive) {
                val t = target
                val sh = shown.get()
                if (sh < t.length) {
                    val back = t.length - sh
                    val n = minOf(t.length, sh + maxOf(1, back / (if (netDone) 5 else 14)))
                    shown.set(n)
                    live = t.substring(0, n)
                }
                delay(16)
            }
        }
        val res = try {
            withContext(Dispatchers.IO) { call { target = it } }
        } catch (e: Throwable) {
            ticker.cancel()
            live = null
            throw e
        }
        target = res
        netDone = true
        while (shown.get() < res.length) delay(16)
        ticker.cancel()
        live = null
        res
    }

    private suspend fun runChat(text: String, taken: List<Att>) {
        val payload = buildUser(text, taken)
        if (payload.digest.isNotEmpty()) messages[messages.lastIndex] = messages.last().copy(hidden = payload.digest)
        val msgs = JSONArray()
        msgs.put(JSONObject().put("role", "system").put("content", sysPrompt()))
        for (m in messages.dropLast(1).filter { it.role == "user" || it.role == "assistant" }.takeLast(12)) {
            val c = if (m.role == "user" && m.hidden.isNotEmpty()) m.text + "\n" + m.hidden else m.text
            msgs.put(JSONObject().put("role", m.role).put("content", c))
        }
        msgs.put(JSONObject().put("role", "user").put("content", payload.content))
        status = "Думаю…"
        val answer = streamAnswer { d ->
            Net.ask(providers.toList(), activeId, msgs, if (taken.isNotEmpty()) 3000 else 1500, payload.vision, true, d)
        }
        messages.add(Msg("assistant", answer))
    }

    private suspend fun review(work: Map<String, CodeFile>, issues: List<String>): String = withContext(Dispatchers.IO) {
        val body = work.entries.joinToString("\n") { e -> "```" + e.value.lang + " path=" + e.key + "\n" + e.value.code + "\n```" }
        val user = (if (issues.isNotEmpty()) "Автоматическая проверка нашла:\n" + issues.joinToString("\n") { "- $it" } + "\n\n" else "") + "Файлы:\n" + body
        val arr = JSONArray()
            .put(JSONObject().put("role", "system").put("content", Code.REVIEW))
            .put(JSONObject().put("role", "user").put("content", user))
        Net.ask(providers.toList(), activeId, arr, 8000, false, true) { }
    }

    private suspend fun runCode(text: String, taken: List<Att>, autoZip: Boolean) {
        for (a in taken) for ((p, c) in a.files) files[normPath(p)] = CodeFile("", c)
        val payload = buildUser(text, taken.filter { it.kind == "image" || it.kind == "doc" || it.kind == "bin" })
        if (payload.digest.isNotEmpty()) messages[messages.lastIndex] = messages.last().copy(hidden = payload.digest)
        val before = files.keys.toSet()

        val msgs = JSONArray()
        msgs.put(JSONObject().put("role", "system").put("content", Code.SYS + Code.projectCtx(files)))
        for (m in messages.dropLast(1).filter { it.role == "user" || it.role == "assistant" }.takeLast(4)) {
            msgs.put(JSONObject().put("role", m.role).put("content", Code.compact(m.text)))
        }
        msgs.put(JSONObject().put("role", "user").put("content", payload.content))

        status = "Пишу код…"
        var ans = streamAnswer { d -> Net.ask(providers.toList(), activeId, msgs, 8000, payload.vision, true, d) }

        val opts = setOf(RegexOption.IGNORE_CASE, RegexOption.MULTILINE)
        val pn = Regex("^\\s*PROJECT\\s*:\\s*([\\w .-]+)", opts).find(ans)
        if (pn != null && fname.isBlank()) {
            fname = pn.groupValues[1].trim().lowercase().replace(Regex("[^a-z0-9._-]+"), "-").trim('-').take(40)
        }
        ans = ans.replace(Regex("^\\s*PROJECT\\s*:.*\\n?", opts), "").trim()

        val got = Code.extractFiles(ans, true)
        if (got.isEmpty()) {
            messages.add(Msg("assistant", ans))
            return
        }
        val work = LinkedHashMap<String, CodeFile>()
        for ((p, f) in got) { work[p] = f; files[p] = f }
        messages.add(Msg("assistant", ans))
        val idx = messages.lastIndex

        val fixed = LinkedHashSet<String>()
        var probs = ""
        var remaining: List<String> = emptyList()
        var round = 0
        while (round < 2) {
            round++
            status = if (round == 1) "Проверяю код…" else "Повторная проверка…"
            val issues = Code.staticCheck(files, work.keys)
            val reply = try {
                review(work, issues)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                remaining = issues
                break
            }
            val fx = if (Regex("^\\s*OK\\b", RegexOption.IGNORE_CASE).containsMatchIn(reply)) emptyList() else Code.extractFiles(reply, false)
            if (fx.isEmpty()) { remaining = issues; break }
            if (probs.isEmpty()) {
                probs = Regex("ПРОБЛЕМЫ:?\\s*([\\s\\S]*?)(?=```|\\z)", RegexOption.IGNORE_CASE).find(reply)?.groupValues?.get(1)?.trim()?.take(700) ?: ""
            }
            status = "Исправляю найденное…"
            for ((p, f) in fx) { work[p] = f; files[p] = f; fixed.add(p) }
            remaining = Code.staticCheck(files, work.keys)
            if (remaining.isEmpty()) break
        }

        var shown = ans
        if (fixed.isNotEmpty()) {
            shown = FENCE.replace(ans) { m ->
                val f = parseFence(m.groupValues[2], m.groupValues[3])
                val w = work[f.path]
                if (f.path.isNotEmpty() && fixed.contains(f.path) && w != null) "```" + w.lang + " path=" + f.path + "\n" + w.code + "\n```" else m.value
            }
        }
        val sb = StringBuilder(shown)
        sb.append("\n\n| Файл | Статус | Строк |\n|---|---|---|\n")
        for (p in work.keys) {
            val lines = (files[p]?.code ?: "").count { it == '\n' } + 1
            sb.append("| ").append(p).append(" | ").append(if (before.contains(p)) "изменён" else "создан").append(" | ").append(lines).append(" |\n")
        }
        sb.append("\n**Проверка кода.** ")
        if (fixed.isNotEmpty()) {
            sb.append("Нашёл и исправил: ").append(fixed.joinToString(", ")).append('.')
            if (probs.isNotEmpty()) sb.append('\n').append(probs)
        } else {
            sb.append("Автоматическая проверка и ревью пройдены, замечаний нет.")
        }
        if (remaining.isNotEmpty()) sb.append("\nОстались замечания: ").append(remaining.joinToString("; ")).append('.')
        messages[idx] = Msg("assistant", sb.toString())
        if (autoZip) zipProject(getApplication<Application>())
    }
}
