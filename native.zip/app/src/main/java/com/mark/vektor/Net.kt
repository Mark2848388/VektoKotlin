package com.mark.vektor

import org.json.JSONArray
import org.json.JSONException
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.ConcurrentHashMap

object Net {
    class ApiError(val code: Int, message: String) : Exception(message)

    private val cooldown = ConcurrentHashMap<String, Long>()

    private fun parseError(body: String, code: Int): String {
        return try {
            val e = JSONObject(body).opt("error")
            when (e) {
                is JSONObject -> e.optString("message", "HTTP $code")
                is String -> e
                else -> "HTTP $code"
            }
        } catch (_: Exception) {
            "HTTP $code"
        }
    }

    private fun request(
        p: Provider,
        key: String,
        messages: JSONArray,
        maxTokens: Int,
        onDelta: (String) -> Unit
    ): String {
        val oss = p.model.contains("gpt-oss")
        val body = JSONObject()
            .put("model", p.model)
            .put("messages", messages)
            .put("max_tokens", if (oss) maxOf(maxTokens, 1500) else maxTokens)
            .put("stream", true)
        if (oss) body.put("reasoning_effort", "low")

        val c = URL(p.base.trimEnd('/') + "/chat/completions").openConnection() as HttpURLConnection
        try {
            c.requestMethod = "POST"
            c.connectTimeout = 20000
            c.readTimeout = 120000
            c.doOutput = true
            c.setRequestProperty("Content-Type", "application/json")
            c.setRequestProperty("Authorization", "Bearer $key")
            c.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }

            val code = c.responseCode
            if (code !in 200..299) {
                val err = (c.errorStream ?: c.inputStream).bufferedReader().use { it.readText() }
                throw ApiError(code, parseError(err, code))
            }

            val sb = StringBuilder()
            c.inputStream.bufferedReader(Charsets.UTF_8).use { r ->
                while (true) {
                    val line = r.readLine() ?: break
                    if (!line.startsWith("data:")) continue
                    val d = line.substring(5).trim()
                    if (d == "[DONE]") break
                    try {
                        val choices = JSONObject(d).optJSONArray("choices")
                        val delta = choices?.optJSONObject(0)?.optJSONObject("delta")
                        if (delta != null && !delta.isNull("content")) {
                            val t = delta.optString("content")
                            if (t.isNotEmpty()) {
                                sb.append(t)
                                onDelta(sb.toString())
                            }
                        }
                    } catch (_: JSONException) {
                    }
                }
            }
            val out = sb.toString().trim()
            if (out.isEmpty()) throw ApiError(0, "пустой ответ модели")
            return out
        } finally {
            c.disconnect()
        }
    }

    /** Спрашивает нейросети по очереди; внутри каждой перебирает ключи (при лимите берёт следующий). */
    fun ask(
        providers: List<Provider>,
        active: String,
        messages: JSONArray,
        maxTokens: Int,
        vision: Boolean,
        failover: Boolean,
        onDelta: (String) -> Unit
    ): String {
        var pool = providers.filter { it.keyList().isNotEmpty() && (!vision || it.vision) }
        val act = pool.find { it.id == active }
        if (act != null) pool = listOf(act) + pool.filter { it.id != act.id }
        if (!failover) pool = pool.take(1)
        if (pool.isEmpty()) {
            throw Exception(
                if (vision) "нет нейросети с поддержкой фото: включите «Понимает фото» в настройках нейросети"
                else "нейросеть не подключена"
            )
        }
        val errs = ArrayList<String>()
        for (p in pool) {
            val now = System.currentTimeMillis()
            val keys = p.keyList().sortedBy { if ((cooldown[it] ?: 0L) > now) 1 else 0 }
            for (k in keys) {
                try {
                    return request(p, k, messages, maxTokens, onDelta)
                } catch (e: ApiError) {
                    errs.add(p.name + ": " + (e.message ?: ""))
                    val until = System.currentTimeMillis()
                    if (e.code == 429) cooldown[k] = until + 90_000L
                    else if (e.code == 401 || e.code == 402 || e.code == 403) cooldown[k] = until + 3_600_000L
                    else if (e.code >= 500) cooldown[k] = until + 20_000L
                    else break
                } catch (e: IOException) {
                    errs.add(p.name + ": сеть: " + (e.message ?: ""))
                    break
                }
            }
        }
        throw Exception(errs.joinToString(" | "))
    }
}
