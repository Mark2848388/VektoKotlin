package com.mark.vektor

import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.ClickableText
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

sealed class Block {
    data class H(val level: Int, val text: String) : Block()
    data class P(val text: String) : Block()
    data class Li(val level: Int, val marker: String, val text: String) : Block()
    data class Q(val text: String) : Block()
    data class Code(val lang: String, val path: String, val code: String) : Block()
    data class Table(val head: List<String>, val rows: List<List<String>>) : Block()
    object Hr : Block()
}

val FENCE = Regex("(`{3,})([^\\n`]*)\\n([\\s\\S]*?)(?:\\1(?!`)|\\z)")

data class Fence(val lang: String, val path: String, val code: String)

fun normPath(p: String): String =
    p.replace('\\', '/').replace(Regex("^[a-zA-Z]:"), "").split('/').filter { it.isNotEmpty() && it != "." && it != ".." }.joinToString("/")

fun parseFence(info: String, codeIn: String): Fence {
    val toks = info.trim().split(Regex("\\s+")).filter { it.isNotEmpty() }.toMutableList()
    var lang = ""
    var path = ""
    if (toks.isNotEmpty() && Regex("^[\\w+#-]+$").matches(toks[0])) lang = toks.removeAt(0).lowercase()
    val kv = Regex("^(?:path|file|filename|title|name)\\s*[=:]\\s*[\"']?(.+?)[\"']?$", RegexOption.IGNORE_CASE)
    for (t in toks) {
        val m = kv.find(t)
        if (m != null) path = m.groupValues[1]
        else if (path.isEmpty() && (t.contains('.') || t.contains('/'))) path = t.trim('"', '\'')
    }
    var code = codeIn.replace("\r", "")
    val firstLine = code.substringBefore('\n')
    val cm = Regex("^\\s*(?://|#|<!--|/\\*|--|;)\\s*(?:file|path|файл|filename)\\s*[:=]\\s*[\"']?([^\\s\"'>*]+)", RegexOption.IGNORE_CASE).find(firstLine)
    if (cm != null) {
        if (path.isEmpty()) path = cm.groupValues[1]
        code = if (code.contains('\n')) code.substringAfter('\n') else ""
    }
    return Fence(lang, normPath(path), code.trimEnd('\n'))
}

private fun splitCells(line: String): List<String> {
    var l = line.trim()
    if (l.startsWith("|")) l = l.substring(1)
    if (l.endsWith("|")) l = l.dropLast(1)
    return l.split(Regex("(?<!\\\\)\\|")).map { it.replace("\\|", "|").trim() }
}

private val SEP = Regex("^\\s*\\|?\\s*:?-{2,}:?\\s*(\\|\\s*:?-{2,}:?\\s*)*\\|?\\s*$")

private fun textBlocks(text: String, out: MutableList<Block>) {
    val lines = text.replace("\t", "  ").split('\n')
    var i = 0
    while (i < lines.size) {
        val s = lines[i].trimEnd()
        if (s.isBlank()) { i++; continue }
        if (s.contains('|') && i + 1 < lines.size && SEP.matches(lines[i + 1]) && splitCells(s).size >= 2) {
            val head = splitCells(s)
            val rows = ArrayList<List<String>>()
            var j = i + 2
            while (j < lines.size && lines[j].contains('|') && lines[j].isNotBlank()) {
                val r = splitCells(lines[j])
                rows.add(List(head.size) { k -> r.getOrElse(k) { "" } })
                j++
            }
            out.add(Block.Table(head, rows))
            i = j
            continue
        }
        val h = Regex("^\\s{0,3}(#{1,6})\\s+(.*?)\\s*#*$").find(s)
        val ul = Regex("^(\\s*)[-*•+]\\s+(.*)").find(s)
        val ol = Regex("^(\\s*)(\\d+[.)])\\s+(.*)").find(s)
        val q = Regex("^\\s*>\\s?(.*)").find(s)
        when {
            h != null -> out.add(Block.H(minOf(h.groupValues[1].length, 3), h.groupValues[2]))
            Regex("^\\s*([-*_])(\\s*\\1){2,}\\s*$").matches(s) -> out.add(Block.Hr)
            q != null -> out.add(Block.Q(q.groupValues[1]))
            ul != null -> {
                val lv = minOf(3, 1 + ul.groupValues[1].length / 2)
                var tx = ul.groupValues[2]
                var mk = if (lv > 1) "–" else "•"
                val cb = Regex("^\\[( |x|X)\\]\\s+(.*)").find(tx)
                if (cb != null) { mk = if (cb.groupValues[1] == " ") "☐" else "☑"; tx = cb.groupValues[2] }
                out.add(Block.Li(lv, mk, tx))
            }
            ol != null -> out.add(Block.Li(minOf(3, 1 + ol.groupValues[1].length / 2), ol.groupValues[2], ol.groupValues[3]))
            else -> out.add(Block.P(s))
        }
        i++
    }
}

fun parseMd(srcIn: String): List<Block> {
    val src = srcIn.replace(Regex("```([^\\n`]+)```"), "`$1`")
    val out = ArrayList<Block>()
    var last = 0
    for (m in FENCE.findAll(src)) {
        if (m.range.first > last) textBlocks(src.substring(last, m.range.first), out)
        val f = parseFence(m.groupValues[2], m.groupValues[3])
        out.add(Block.Code(f.lang, f.path, f.code))
        last = m.range.last + 1
    }
    if (last < src.length) textBlocks(src.substring(last), out)
    return out
}

private val INLINE = Regex(
    "`[^`\\n]+`|\\*\\*[^*\\n]+?\\*\\*|__[^_\\n]+?__|~~[^~\\n]+?~~|\\[[^\\]\\n]+\\]\\(https?://[^)\\s]+\\)" +
        "|(?<![\\p{L}\\p{N}*])\\*[^*\\s][^*\\n]*?\\*(?![\\p{L}\\p{N}*])|(?<![\\p{L}\\p{N}_])_[^_\\s][^_\\n]*?_(?![\\p{L}\\p{N}_])"
)

fun inlineMd(t: String, v: VColors, base: SpanStyle? = null): AnnotatedString = buildAnnotatedString {
    fun go(s: String) {
        var last = 0
        for (m in INLINE.findAll(s)) {
            if (m.range.first > last) append(s.substring(last, m.range.first))
            val x = m.value
            when {
                x.startsWith("`") -> withStyle(
                    SpanStyle(fontFamily = FontFamily.Monospace, background = v.card2, fontSize = 14.sp)
                ) { append(x.substring(1, x.length - 1)) }
                x.startsWith("**") || x.startsWith("__") -> withStyle(SpanStyle(fontWeight = FontWeight.Bold)) { go(x.substring(2, x.length - 2)) }
                x.startsWith("~~") -> withStyle(SpanStyle(textDecoration = TextDecoration.LineThrough)) { go(x.substring(2, x.length - 2)) }
                x.startsWith("[") -> {
                    val mm = Regex("^\\[(.+?)\\]\\((.+)\\)$").find(x)
                    if (mm != null) {
                        pushStringAnnotation("URL", mm.groupValues[2])
                        withStyle(SpanStyle(color = v.accent, textDecoration = TextDecoration.Underline)) { go(mm.groupValues[1]) }
                        pop()
                    } else append(x)
                }
                else -> withStyle(SpanStyle(fontStyle = FontStyle.Italic)) { go(x.substring(1, x.length - 1)) }
            }
            last = m.range.last + 1
        }
        if (last < s.length) append(s.substring(last))
    }
    if (base != null) withStyle(base) { go(t) } else go(t)
}

fun openUrl(ctx: Context, url: String) {
    try {
        ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    } catch (_: Exception) {}
}

@Composable
private fun MdText(text: String, v: VColors, style: TextStyle, modifier: Modifier = Modifier, base: SpanStyle? = null) {
    val ctx = LocalContext.current
    val ann = remember(text, v) { inlineMd(text, v, base) }
    if (ann.getStringAnnotations("URL", 0, ann.length).isNotEmpty()) {
        ClickableText(ann, modifier = modifier, style = style) { off ->
            ann.getStringAnnotations("URL", off, off).firstOrNull()?.let { openUrl(ctx, it.item) }
        }
    } else {
        Text(ann, modifier = modifier, style = style)
    }
}

@Composable
fun CodeBlock(lang: String, path: String, code: String, v: VColors, onCopy: (String) -> Unit) {
    Column(
        Modifier.padding(vertical = 6.dp).fillMaxWidth()
            .border(1.dp, v.line, RoundedCornerShape(12.dp))
            .background(v.card2, RoundedCornerShape(12.dp))
    ) {
        Row(Modifier.fillMaxWidth().padding(start = 12.dp, end = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(
                if (path.isNotEmpty()) path else if (lang.isNotEmpty()) lang else "код",
                color = v.muted, fontSize = 12.sp, fontFamily = FontFamily.Monospace,
                modifier = Modifier.weight(1f)
            )
            Text(
                "Копировать", color = v.muted, fontSize = 12.sp,
                modifier = Modifier.clickable { onCopy(code) }.padding(horizontal = 10.dp, vertical = 8.dp)
            )
        }
        Box(Modifier.fillMaxWidth().height(1.dp).background(v.line))
        Text(
            code, color = v.text, fontFamily = FontFamily.Monospace, fontSize = 13.sp, lineHeight = 19.sp,
            softWrap = false,
            modifier = Modifier.horizontalScroll(rememberScrollState()).padding(12.dp)
        )
    }
}

@Composable
fun TableView(head: List<String>, rows: List<List<String>>, v: VColors) {
    val widths = head.indices.map { c ->
        val longest = (listOf(head[c]) + rows.map { it.getOrElse(c) { "" } }).maxOf { it.length }
        (longest * 8 + 24).coerceIn(72, 220).dp
    }
    Column(
        Modifier.padding(vertical = 6.dp)
            .border(1.dp, v.line, RoundedCornerShape(12.dp))
            .horizontalScroll(rememberScrollState())
    ) {
        Row(Modifier.background(v.card2)) {
            head.forEachIndexed { i, h ->
                Text(h, fontWeight = FontWeight.Bold, color = v.text, fontSize = 13.5.sp, modifier = Modifier.width(widths[i]).padding(8.dp))
            }
        }
        rows.forEach { r ->
            Box(Modifier.fillMaxWidth().height(1.dp).background(v.line))
            Row {
                r.forEachIndexed { i, c ->
                    MdText(c, v, TextStyle(color = v.text, fontSize = 13.5.sp), Modifier.width(widths[i]).padding(8.dp))
                }
            }
        }
    }
}

@Composable
fun MdView(text: String, v: VColors, serif: Boolean, onCopy: (String) -> Unit) {
    val blocks = remember(text) { parseMd(text) }
    val fam = if (serif) FontFamily.Serif else FontFamily.Default
    val body = TextStyle(color = v.text, fontSize = 16.5.sp, lineHeight = 26.sp, fontFamily = fam)
    Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(5.dp)) {
        for (b in blocks) {
            when (b) {
                is Block.H -> MdText(
                    b.text, v,
                    body.copy(fontSize = if (b.level == 1) 21.sp else if (b.level == 2) 18.5.sp else 17.sp, fontWeight = FontWeight.Bold, lineHeight = 28.sp),
                    Modifier.padding(top = 8.dp)
                )
                is Block.P -> MdText(b.text, v, body)
                is Block.Li -> MdText(b.marker + " " + b.text, v, body, Modifier.padding(start = (12 * (b.level - 1)).dp))
                is Block.Q -> Row(Modifier.padding(vertical = 2.dp)) {
                    Box(Modifier.width(3.dp).height(24.dp).background(v.line))
                    MdText(b.text, v, body.copy(color = v.muted), Modifier.padding(start = 10.dp))
                }
                is Block.Code -> CodeBlock(b.lang, b.path, b.code, v, onCopy)
                is Block.Table -> TableView(b.head, b.rows, v)
                is Block.Hr -> Box(Modifier.padding(vertical = 6.dp).fillMaxWidth().height(1.dp).background(v.line))
            }
        }
    }
}
