package com.mark.vektor

object Code {
    val SYS = """Ты VKTR Code — старший инженер-программист уровня Claude Code. Работаешь как опытный разработчик в команде: сначала понимаешь задачу, потом проектируешь, потом пишешь код, который можно сразу запустить.

ПРИНЦИПЫ
- Полнота: никаких заглушек и сокращений («...», «остальное без изменений», TODO вместо реализации). Каждый файл — целиком.
- Корректность: продумай граничные случаи, ошибки ввода-вывода, пустые данные. Не выдумывай несуществующие API и функции библиотек; если не уверен, используй стандартную библиотеку.
- Согласованность: имена функций, id элементов, импорты, пути и типы совпадают между файлами. Перед ответом мысленно «запусти» код и проверь.
- Качество: чистая структура, понятные имена, комментарии только там, где логика неочевидна. Современный стабильный синтаксис, без устаревших API.
- Безопасность: валидация входа, никаких секретов в коде, защита от инъекций и XSS.
- Интерфейсы: адаптивные, доступные (метки, контраст, фокус), аккуратный современный дизайн.
- Тесты: для нетривиальной логики добавляй тесты и команду запуска.
- Правки: если проект уже есть (см. файлы ниже), меняй минимально необходимое и выдавай изменённые файлы ЦЕЛИКОМ, сохраняя стиль проекта.

ФОРМАТ ОТВЕТА, когда нужен код
1) Первой строкой: PROJECT: короткое-имя-латиницей (только для нового проекта).
2) Раздел «План»: 3–6 коротких пунктов (что и в каких файлах делаем, ключевые решения).
3) Каждый файл отдельным блоком. Заголовок СТРОГО: три обратных кавычки, язык, пробел, path=относительный/путь/файла.ext, затем код и закрывающие три обратные кавычки. Пути без начального слэша.
4) Для приложения создай ВСЕ файлы, нужные для запуска (README.md, файл зависимостей, конфигурацию). В README.md не используй вложенные блоки кода, команды оформляй отступом в 4 пробела.
5) В конце раздел «Как запустить» на 2–5 строк.
Если вопрос не про создание кода (объяснить, найти ошибку, сравнить подходы), отвечай кратко и по делу, с примерами. Таблицы и списки оформляй в markdown. Пиши по-русски; код и идентификаторы на английском."""

    val REVIEW = """Ты строгий ревьюер кода. Проверь файлы: синтаксис, логические ошибки, обработку ошибок, несостыковки между файлами (имена функций, id элементов, импорты, пути), неполный код, очевидные проблемы безопасности.
Если проблем нет — ответь ровно одним словом: OK.
Если проблемы есть — сначала строка «ПРОБЛЕМЫ:» и до 5 коротких пунктов, затем ПОЛНЫЕ исправленные версии только изменённых файлов в том же формате блоков (три обратные кавычки, язык, path=путь, код, три обратные кавычки). Ничего не сокращай."""

    val CHAT_SUFFIX = "На обычные вопросы отвечай коротко, 1–3 предложения, простым текстом. Если просят таблицу, сравнение, список, инструкцию или код — оформляй markdown: таблицы через |, списки, **выделение**, блоки кода."

    private val EXT = mapOf(
        "js" to "js", "javascript" to "js", "ts" to "ts", "typescript" to "ts", "py" to "py", "python" to "py",
        "html" to "html", "css" to "css", "json" to "json", "kt" to "kt", "kotlin" to "kt", "java" to "java",
        "cs" to "cs", "cpp" to "cpp", "c" to "c", "go" to "go", "rs" to "rs", "php" to "php", "rb" to "rb",
        "sh" to "sh", "bash" to "sh", "sql" to "sql", "md" to "md", "yml" to "yml", "yaml" to "yml", "xml" to "xml"
    )

    private val PLACE = Regex(
        "(\\.\\.\\.\\s*(остальн|rest of|existing|your code|код здесь)|//\\s*(остальной|rest of|\\.\\.\\.|your code)|TODO:?\\s*(implement|реализ|добав)|остальной код без изменений)",
        RegexOption.IGNORE_CASE
    )

    fun extractFiles(text: String, allowDefault: Boolean): List<Pair<String, CodeFile>> {
        val all = FENCE.findAll(text).map { parseFence(it.groupValues[2], it.groupValues[3]) }.toList()
        val out = all.filter { it.path.isNotEmpty() }.map { Pair(it.path, CodeFile(it.lang, it.code)) }.toMutableList()
        if (allowDefault && out.isEmpty() && all.size == 1 && EXT.containsKey(all[0].lang)) {
            out.add(Pair("main." + EXT[all[0].lang], CodeFile(all[0].lang, all[0].code)))
        }
        return out
    }

    fun compact(text: String): String = FENCE.replace(text) { m ->
        val f = parseFence(m.groupValues[2], m.groupValues[3])
        "[файл " + (if (f.path.isNotEmpty()) f.path else if (f.lang.isNotEmpty()) f.lang else "код") + ", " + (m.groupValues[3].count { it == '\n' } + 1) + " строк]"
    }

    fun projectCtx(files: Map<String, CodeFile>): String {
        if (files.isEmpty()) return ""
        var left = 28000
        val sb = StringBuilder("\n\nТЕКУЩИЕ ФАЙЛЫ ПРОЕКТА (учитывай их и правь согласованно):\n")
        for ((p, f) in files) {
            if (f.code.length <= left) {
                sb.append("--- ").append(p).append('\n').append(f.code).append('\n')
                left -= f.code.length
            } else {
                sb.append("--- ").append(p).append(" (содержимое пропущено, ").append(f.code.length).append(" символов)\n")
            }
        }
        return sb.toString()
    }

    /** Лёгкая проверка без запуска кода: пустые файлы, заглушки, JSON, ссылки между файлами в HTML. */
    fun staticCheck(files: Map<String, CodeFile>, only: Collection<String>): List<String> {
        val issues = ArrayList<String>()
        for (p in only) {
            val f = files[p] ?: continue
            val c = f.code
            val ext = p.substringAfterLast('.', "").lowercase()
            if (c.isBlank()) { issues.add("$p — файл пустой"); continue }
            if (PLACE.containsMatchIn(c)) issues.add("$p — есть заглушка или сокращение вместо кода")
            if (ext == "json") {
                try { org.json.JSONTokener(c).nextValue() } catch (e: Exception) { issues.add("$p — некорректный JSON: " + (e.message ?: "")) }
            }
            if (ext == "html" || ext == "htm") {
                val dir = if (p.contains('/')) p.substring(0, p.lastIndexOf('/') + 1) else ""
                val re = Regex("<(?:script[^>]*\\ssrc|link[^>]*\\shref)\\s*=\\s*[\"']([^\"']+)[\"']", RegexOption.IGNORE_CASE)
                for (m in re.findAll(c)) {
                    val u = m.groupValues[1]
                    if (Regex("^(https?:|//|data:|#|mailto:)", RegexOption.IGNORE_CASE).containsMatchIn(u)) continue
                    val full = normPath(dir + u.substringBefore('?').substringBefore('#'))
                    if (!files.containsKey(full)) issues.add("$p — ссылается на отсутствующий файл $u")
                }
            }
        }
        return issues
    }
}
